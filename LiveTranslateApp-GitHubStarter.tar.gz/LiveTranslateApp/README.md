
# LiveTranslateApp

Aplikasi Android sederhana untuk menerjemahkan teks secara langsung dari layar menggunakan OCR dan menampilkannya sebagai overlay.

Fitur:
- OCR dari layar (menggunakan Google ML Kit)
- Terjemahan otomatis ke Bahasa Indonesia
- Overlay mengambang di atas aplikasi lain
- Dibuat untuk membantu menonton video seperti Douyin berbahasa Mandarin

Dibuat untuk: https://github.com/lockband22/LiveTranslateApp
